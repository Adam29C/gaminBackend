const  adminDashboard  = require('./adminDashboard');

const controller = {
    adminDashboard: adminDashboard
};

module.exports = controller; 
