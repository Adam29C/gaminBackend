const  subAdminDashboard  = require('./subAdminDashboard');

// Create an object to hold references to userController and adminController and subAdminDashboard
const controller = {
    subAdminDashboard: subAdminDashboard
};

module.exports = controller; 
