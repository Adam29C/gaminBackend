const userDashboard = require('./userDashboard');

// Create an object to hold references to userDashboard and adminController and subAdminController
const controller = {
    userDashboard: userDashboard
};

module.exports = controller;  